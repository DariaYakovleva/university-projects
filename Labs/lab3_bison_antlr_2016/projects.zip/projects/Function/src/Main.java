
import java.io.*;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Properties;
import javax.tools.JavaCompiler;
import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Женя
 */
public class Main {

    public static void main(String[] args) throws Exception {
        File program = new File("program.txt");
        //ANTLRInputStream input = new ANTLRInputStream(System.in);
        //ANTLRInputStream input = new ANTLRInputStream(new FileInputStream(args[0]));
        ANTLRInputStream input = new ANTLRInputStream(new FileInputStream(program));
        SLLexer lexer = new SLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        SLParser parser = new SLParser(tokens);
        CommonTree tree = (CommonTree) parser.prog().getTree();

        System.out.println("Tree: " + tree + "\n");
        visit(tree, "");
        System.out.println("");

        //*
        CodeGenerator codeGen = new CodeGenerator();
        codeGen.handle(tree);
        //System.out.println("code:");
        System.out.println(codeGen.getSource());

        //String out = args[1] + "/Main.java";
        String out = "simple";
        new File(out).mkdirs();
        String file = out + "/Main.java";
        save(file, codeGen.getSource());
        compile(file);
        run("simple.Main");
        //*/
    }

    static void visit(Tree tree, String s){
        //System.out.println(s + "text: " + tree.getText() + ", type: " + tree.getType() + ", childs: " + tree.getChildCount());
        System.out.println(s + "text: " + tree.getText() + ", childs: " + tree.getChildCount());
        for(int i=0; i< tree.getChildCount(); i++){
            visit(tree.getChild(i), s +"  ");
        }

        //System.out.println(tree.toStringTree());
    }

    static String getBase(){
        return System.getProperty("user.dir").replace('\\', '/');
    }


    static void save(String file, StringBuilder code) throws IOException {
        OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(file));
        out.append(code);
        out.close();
    }

    static void compile(String file) throws IOException {
        System.out.println("compile: " + file);
        JavaCompiler compiler = javax.tools.ToolProvider.getSystemJavaCompiler();
        compiler.run(System.in, System.out, System.err, file);
    }
    static void run(String file) throws Exception{
        System.out.println();
        String base = "file://" + getBase() + "/dist/";
        //System.out.println("Base: " + base);
        URL url = new URL(base);
        URLClassLoader classLoader = new URLClassLoader(new URL[]{url});
        Class main = classLoader.loadClass("simple.Main");

        Object obj = main.newInstance();
        String[] args = new String[]{"1", "2"};
        Object[] passedArgs = new Object[]{ args};
        Method mainMethod = main.getMethod("main", args.getClass());
        mainMethod.invoke(obj, passedArgs);
    }
}
