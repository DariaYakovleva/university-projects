package simple;
import static java.lang.Math.*;

public class Main{

  static double sqr( double x ) { return x * x ; } 

  static double sqrt( double x ) { return Math.pow( x , 0.5 ) ; } 

  static double root1( double a , double b , double c ) { return ( -b - sqrt ( sqr ( b ) - 4 * a * c ) ) / ( 2 * a ) ; } 

  static double root2( double a , double b , double c ) { return ( -b + sqrt ( sqr ( b ) - 4 * a * c ) ) / ( 2 * a ) ; } 

  public static void main(String args[]){
    System.out.println( "root1 ( 1 , -7 , 10 )  = " + ( root1 ( 1 , -7 , 10 ) ) );
    System.out.println( "root2 ( 1 , -7 , 10 )  = " + ( root2 ( 1 , -7 , 10 ) ) );
  }
}