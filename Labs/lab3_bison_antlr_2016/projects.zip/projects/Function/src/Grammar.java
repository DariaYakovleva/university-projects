
import java.io.File;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author andromeda
 */
public class Grammar {

    public static void main(String[] args) {
        File dir = new File(".");
        System.out.println("current dir: " + dir.getAbsolutePath());

        String src = new File("src").getAbsolutePath();
        String grammar = new File("src/SL.g").getAbsolutePath();

        org.antlr.Tool.main(new String[]{"-o", src, grammar});
    }
}
