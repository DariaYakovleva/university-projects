// $ANTLR 3.2 Sep 23, 2009 12:02:23 src/SL.g 2010-11-17 17:58:45

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class SLLexer extends Lexer {
    public static final int FUNCTION=15;
    public static final int STAR=6;
    public static final int FUNCTION_DECLARATOR=23;
    public static final int LETTER=27;
    public static final int NUMBER=25;
    public static final int POWER=11;
    public static final int MINUS=5;
    public static final int EOF=-1;
    public static final int SEMI=9;
    public static final int STATEMENT=20;
    public static final int LPAREN=12;
    public static final int TYPE=17;
    public static final int SKIP=29;
    public static final int COLON=10;
    public static final int BRACKETS=19;
    public static final int T__30=30;
    public static final int RPAREN=13;
    public static final int T__31=31;
    public static final int NAME=16;
    public static final int T__32=32;
    public static final int IDENTIFIER=26;
    public static final int ARGUMENT=18;
    public static final int ASSIGN=14;
    public static final int ARGUMENT_LIST=22;
    public static final int PLUS=4;
    public static final int DIGIT=28;
    public static final int DIV=7;
    public static final int DOT=8;
    public static final int FUNCTION_DECLARATION=24;
    public static final int EXPRESSION=21;

    // delegates
    // delegators

    public SLLexer() {;} 
    public SLLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public SLLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "src/SL.g"; }

    // $ANTLR start "PLUS"
    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:3:6: ( '+' )
            // src/SL.g:3:8: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PLUS"

    // $ANTLR start "MINUS"
    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:4:7: ( '-' )
            // src/SL.g:4:9: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MINUS"

    // $ANTLR start "STAR"
    public final void mSTAR() throws RecognitionException {
        try {
            int _type = STAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:5:6: ( '*' )
            // src/SL.g:5:8: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STAR"

    // $ANTLR start "DIV"
    public final void mDIV() throws RecognitionException {
        try {
            int _type = DIV;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:6:5: ( '/' )
            // src/SL.g:6:7: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DIV"

    // $ANTLR start "DOT"
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:7:5: ( '.' )
            // src/SL.g:7:7: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "SEMI"
    public final void mSEMI() throws RecognitionException {
        try {
            int _type = SEMI;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:8:6: ( ';' )
            // src/SL.g:8:8: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SEMI"

    // $ANTLR start "COLON"
    public final void mCOLON() throws RecognitionException {
        try {
            int _type = COLON;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:9:7: ( ':' )
            // src/SL.g:9:9: ':'
            {
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COLON"

    // $ANTLR start "POWER"
    public final void mPOWER() throws RecognitionException {
        try {
            int _type = POWER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:10:7: ( '^' )
            // src/SL.g:10:9: '^'
            {
            match('^'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "POWER"

    // $ANTLR start "LPAREN"
    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:11:8: ( '(' )
            // src/SL.g:11:10: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LPAREN"

    // $ANTLR start "RPAREN"
    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:12:8: ( ')' )
            // src/SL.g:12:10: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RPAREN"

    // $ANTLR start "ASSIGN"
    public final void mASSIGN() throws RecognitionException {
        try {
            int _type = ASSIGN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:13:8: ( '=' )
            // src/SL.g:13:10: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ASSIGN"

    // $ANTLR start "FUNCTION"
    public final void mFUNCTION() throws RecognitionException {
        try {
            int _type = FUNCTION;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:14:10: ( 'function' )
            // src/SL.g:14:12: 'function'
            {
            match("function"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "FUNCTION"

    // $ANTLR start "T__30"
    public final void mT__30() throws RecognitionException {
        try {
            int _type = T__30;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:15:7: ( '{' )
            // src/SL.g:15:9: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__30"

    // $ANTLR start "T__31"
    public final void mT__31() throws RecognitionException {
        try {
            int _type = T__31;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:16:7: ( '}' )
            // src/SL.g:16:9: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__31"

    // $ANTLR start "T__32"
    public final void mT__32() throws RecognitionException {
        try {
            int _type = T__32;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:17:7: ( ',' )
            // src/SL.g:17:9: ','
            {
            match(','); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__32"

    // $ANTLR start "IDENTIFIER"
    public final void mIDENTIFIER() throws RecognitionException {
        try {
            int _type = IDENTIFIER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:112:3: ( LETTER ( LETTER | DIGIT )* )
            // src/SL.g:112:5: LETTER ( LETTER | DIGIT )*
            {
            mLETTER(); 
            // src/SL.g:112:12: ( LETTER | DIGIT )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='Z')||(LA1_0>='a' && LA1_0<='z')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // src/SL.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IDENTIFIER"

    // $ANTLR start "NUMBER"
    public final void mNUMBER() throws RecognitionException {
        try {
            int _type = NUMBER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:117:3: ( ( DIGIT )+ ( '.' ( DIGIT )+ )* )
            // src/SL.g:117:5: ( DIGIT )+ ( '.' ( DIGIT )+ )*
            {
            // src/SL.g:117:5: ( DIGIT )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='0' && LA2_0<='9')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // src/SL.g:117:5: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            // src/SL.g:117:12: ( '.' ( DIGIT )+ )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0=='.') ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // src/SL.g:117:13: '.' ( DIGIT )+
            	    {
            	    match('.'); 
            	    // src/SL.g:117:17: ( DIGIT )+
            	    int cnt3=0;
            	    loop3:
            	    do {
            	        int alt3=2;
            	        int LA3_0 = input.LA(1);

            	        if ( ((LA3_0>='0' && LA3_0<='9')) ) {
            	            alt3=1;
            	        }


            	        switch (alt3) {
            	    	case 1 :
            	    	    // src/SL.g:117:17: DIGIT
            	    	    {
            	    	    mDIGIT(); 

            	    	    }
            	    	    break;

            	    	default :
            	    	    if ( cnt3 >= 1 ) break loop3;
            	                EarlyExitException eee =
            	                    new EarlyExitException(3, input);
            	                throw eee;
            	        }
            	        cnt3++;
            	    } while (true);


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NUMBER"

    // $ANTLR start "DIGIT"
    public final void mDIGIT() throws RecognitionException {
        try {
            // src/SL.g:121:3: ( '0' .. '9' )
            // src/SL.g:121:5: '0' .. '9'
            {
            matchRange('0','9'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end "DIGIT"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // src/SL.g:124:3: ( 'a' .. 'z' | 'A' .. 'Z' )
            // src/SL.g:
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "SKIP"
    public final void mSKIP() throws RecognitionException {
        try {
            int _type = SKIP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/SL.g:130:3: ( ( ' ' | '\\r' | '\\t' | '\\n' | ';' ) )
            // src/SL.g:130:5: ( ' ' | '\\r' | '\\t' | '\\n' | ';' )
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' '||input.LA(1)==';' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

             skip(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SKIP"

    public void mTokens() throws RecognitionException {
        // src/SL.g:1:8: ( PLUS | MINUS | STAR | DIV | DOT | SEMI | COLON | POWER | LPAREN | RPAREN | ASSIGN | FUNCTION | T__30 | T__31 | T__32 | IDENTIFIER | NUMBER | SKIP )
        int alt5=18;
        alt5 = dfa5.predict(input);
        switch (alt5) {
            case 1 :
                // src/SL.g:1:10: PLUS
                {
                mPLUS(); 

                }
                break;
            case 2 :
                // src/SL.g:1:15: MINUS
                {
                mMINUS(); 

                }
                break;
            case 3 :
                // src/SL.g:1:21: STAR
                {
                mSTAR(); 

                }
                break;
            case 4 :
                // src/SL.g:1:26: DIV
                {
                mDIV(); 

                }
                break;
            case 5 :
                // src/SL.g:1:30: DOT
                {
                mDOT(); 

                }
                break;
            case 6 :
                // src/SL.g:1:34: SEMI
                {
                mSEMI(); 

                }
                break;
            case 7 :
                // src/SL.g:1:39: COLON
                {
                mCOLON(); 

                }
                break;
            case 8 :
                // src/SL.g:1:45: POWER
                {
                mPOWER(); 

                }
                break;
            case 9 :
                // src/SL.g:1:51: LPAREN
                {
                mLPAREN(); 

                }
                break;
            case 10 :
                // src/SL.g:1:58: RPAREN
                {
                mRPAREN(); 

                }
                break;
            case 11 :
                // src/SL.g:1:65: ASSIGN
                {
                mASSIGN(); 

                }
                break;
            case 12 :
                // src/SL.g:1:72: FUNCTION
                {
                mFUNCTION(); 

                }
                break;
            case 13 :
                // src/SL.g:1:81: T__30
                {
                mT__30(); 

                }
                break;
            case 14 :
                // src/SL.g:1:87: T__31
                {
                mT__31(); 

                }
                break;
            case 15 :
                // src/SL.g:1:93: T__32
                {
                mT__32(); 

                }
                break;
            case 16 :
                // src/SL.g:1:99: IDENTIFIER
                {
                mIDENTIFIER(); 

                }
                break;
            case 17 :
                // src/SL.g:1:110: NUMBER
                {
                mNUMBER(); 

                }
                break;
            case 18 :
                // src/SL.g:1:117: SKIP
                {
                mSKIP(); 

                }
                break;

        }

    }


    protected DFA5 dfa5 = new DFA5(this);
    static final String DFA5_eotS =
        "\14\uffff\1\20\7\uffff\6\20\1\33\1\uffff";
    static final String DFA5_eofS =
        "\34\uffff";
    static final String DFA5_minS =
        "\1\11\13\uffff\1\165\7\uffff\1\156\1\143\1\164\1\151\1\157\1\156"+
        "\1\60\1\uffff";
    static final String DFA5_maxS =
        "\1\175\13\uffff\1\165\7\uffff\1\156\1\143\1\164\1\151\1\157\1\156"+
        "\1\172\1\uffff";
    static final String DFA5_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\uffff"+
        "\1\15\1\16\1\17\1\20\1\21\1\22\1\6\7\uffff\1\14";
    static final String DFA5_specialS =
        "\34\uffff}>";
    static final String[] DFA5_transitionS = {
            "\2\22\2\uffff\1\22\22\uffff\1\22\7\uffff\1\11\1\12\1\3\1\1"+
            "\1\17\1\2\1\5\1\4\12\21\1\7\1\6\1\uffff\1\13\3\uffff\32\20\3"+
            "\uffff\1\10\2\uffff\5\20\1\14\24\20\1\15\1\uffff\1\16",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\24",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\25",
            "\1\26",
            "\1\27",
            "\1\30",
            "\1\31",
            "\1\32",
            "\12\20\7\uffff\32\20\6\uffff\32\20",
            ""
    };

    static final short[] DFA5_eot = DFA.unpackEncodedString(DFA5_eotS);
    static final short[] DFA5_eof = DFA.unpackEncodedString(DFA5_eofS);
    static final char[] DFA5_min = DFA.unpackEncodedStringToUnsignedChars(DFA5_minS);
    static final char[] DFA5_max = DFA.unpackEncodedStringToUnsignedChars(DFA5_maxS);
    static final short[] DFA5_accept = DFA.unpackEncodedString(DFA5_acceptS);
    static final short[] DFA5_special = DFA.unpackEncodedString(DFA5_specialS);
    static final short[][] DFA5_transition;

    static {
        int numStates = DFA5_transitionS.length;
        DFA5_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA5_transition[i] = DFA.unpackEncodedString(DFA5_transitionS[i]);
        }
    }

    class DFA5 extends DFA {

        public DFA5(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 5;
            this.eot = DFA5_eot;
            this.eof = DFA5_eof;
            this.min = DFA5_min;
            this.max = DFA5_max;
            this.accept = DFA5_accept;
            this.special = DFA5_special;
            this.transition = DFA5_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( PLUS | MINUS | STAR | DIV | DOT | SEMI | COLON | POWER | LPAREN | RPAREN | ASSIGN | FUNCTION | T__30 | T__31 | T__32 | IDENTIFIER | NUMBER | SKIP );";
        }
    }
 

}