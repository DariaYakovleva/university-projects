// $ANTLR 3.2 Sep 23, 2009 12:02:23 src/SL.g 2010-11-17 17:58:44

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class SLParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "PLUS", "MINUS", "STAR", "DIV", "DOT", "SEMI", "COLON", "POWER", "LPAREN", "RPAREN", "ASSIGN", "FUNCTION", "NAME", "TYPE", "ARGUMENT", "BRACKETS", "STATEMENT", "EXPRESSION", "ARGUMENT_LIST", "FUNCTION_DECLARATOR", "FUNCTION_DECLARATION", "NUMBER", "IDENTIFIER", "LETTER", "DIGIT", "SKIP", "'{'", "'}'", "','"
    };
    public static final int FUNCTION=15;
    public static final int STAR=6;
    public static final int FUNCTION_DECLARATOR=23;
    public static final int LETTER=27;
    public static final int NUMBER=25;
    public static final int POWER=11;
    public static final int MINUS=5;
    public static final int EOF=-1;
    public static final int SEMI=9;
    public static final int STATEMENT=20;
    public static final int LPAREN=12;
    public static final int TYPE=17;
    public static final int SKIP=29;
    public static final int COLON=10;
    public static final int BRACKETS=19;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int RPAREN=13;
    public static final int T__32=32;
    public static final int NAME=16;
    public static final int IDENTIFIER=26;
    public static final int ARGUMENT=18;
    public static final int ASSIGN=14;
    public static final int ARGUMENT_LIST=22;
    public static final int PLUS=4;
    public static final int DIGIT=28;
    public static final int DIV=7;
    public static final int FUNCTION_DECLARATION=24;
    public static final int DOT=8;
    public static final int EXPRESSION=21;

    // delegates
    // delegators


        public SLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SLParser.tokenNames; }
    public String getGrammarFileName() { return "src/SL.g"; }


    public static class prog_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prog"
    // src/SL.g:42:1: prog : ( stat )+ ;
    public final SLParser.prog_return prog() throws RecognitionException {
        SLParser.prog_return retval = new SLParser.prog_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        SLParser.stat_return stat1 = null;



        try {
            // src/SL.g:43:3: ( ( stat )+ )
            // src/SL.g:43:5: ( stat )+
            {
            root_0 = (CommonTree)adaptor.nil();

            // src/SL.g:43:5: ( stat )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=PLUS && LA1_0<=MINUS)||LA1_0==LPAREN||LA1_0==FUNCTION||(LA1_0>=NUMBER && LA1_0<=IDENTIFIER)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // src/SL.g:43:5: stat
            	    {
            	    pushFollow(FOLLOW_stat_in_prog296);
            	    stat1=stat();

            	    state._fsp--;

            	    adaptor.addChild(root_0, stat1.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prog"

    public static class stat_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "stat"
    // src/SL.g:46:1: stat : ( additiveExpression ';' -> ^( EXPRESSION additiveExpression ) | functionDeclaration -> ^( FUNCTION_DECLARATION functionDeclaration ) );
    public final SLParser.stat_return stat() throws RecognitionException {
        SLParser.stat_return retval = new SLParser.stat_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal3=null;
        SLParser.additiveExpression_return additiveExpression2 = null;

        SLParser.functionDeclaration_return functionDeclaration4 = null;


        CommonTree char_literal3_tree=null;
        RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
        RewriteRuleSubtreeStream stream_additiveExpression=new RewriteRuleSubtreeStream(adaptor,"rule additiveExpression");
        RewriteRuleSubtreeStream stream_functionDeclaration=new RewriteRuleSubtreeStream(adaptor,"rule functionDeclaration");
        try {
            // src/SL.g:47:3: ( additiveExpression ';' -> ^( EXPRESSION additiveExpression ) | functionDeclaration -> ^( FUNCTION_DECLARATION functionDeclaration ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( ((LA2_0>=PLUS && LA2_0<=MINUS)||LA2_0==LPAREN||(LA2_0>=NUMBER && LA2_0<=IDENTIFIER)) ) {
                alt2=1;
            }
            else if ( (LA2_0==FUNCTION) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // src/SL.g:47:5: additiveExpression ';'
                    {
                    pushFollow(FOLLOW_additiveExpression_in_stat311);
                    additiveExpression2=additiveExpression();

                    state._fsp--;

                    stream_additiveExpression.add(additiveExpression2.getTree());
                    char_literal3=(Token)match(input,SEMI,FOLLOW_SEMI_in_stat313);  
                    stream_SEMI.add(char_literal3);



                    // AST REWRITE
                    // elements: additiveExpression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 47:28: -> ^( EXPRESSION additiveExpression )
                    {
                        // src/SL.g:47:31: ^( EXPRESSION additiveExpression )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXPRESSION, "EXPRESSION"), root_1);

                        adaptor.addChild(root_1, stream_additiveExpression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // src/SL.g:48:5: functionDeclaration
                    {
                    pushFollow(FOLLOW_functionDeclaration_in_stat327);
                    functionDeclaration4=functionDeclaration();

                    state._fsp--;

                    stream_functionDeclaration.add(functionDeclaration4.getTree());


                    // AST REWRITE
                    // elements: functionDeclaration
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 48:28: -> ^( FUNCTION_DECLARATION functionDeclaration )
                    {
                        // src/SL.g:48:31: ^( FUNCTION_DECLARATION functionDeclaration )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FUNCTION_DECLARATION, "FUNCTION_DECLARATION"), root_1);

                        adaptor.addChild(root_1, stream_functionDeclaration.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "stat"

    public static class functionDeclaration_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "functionDeclaration"
    // src/SL.g:52:1: functionDeclaration : 'function' name '(' ( argumentList )? ')' ':' type '{' additiveExpression '}' -> name type ^( ARGUMENT_LIST ( argumentList )? ) ^( EXPRESSION additiveExpression ) ;
    public final SLParser.functionDeclaration_return functionDeclaration() throws RecognitionException {
        SLParser.functionDeclaration_return retval = new SLParser.functionDeclaration_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token string_literal5=null;
        Token char_literal7=null;
        Token char_literal9=null;
        Token char_literal10=null;
        Token char_literal12=null;
        Token char_literal14=null;
        SLParser.name_return name6 = null;

        SLParser.argumentList_return argumentList8 = null;

        SLParser.type_return type11 = null;

        SLParser.additiveExpression_return additiveExpression13 = null;


        CommonTree string_literal5_tree=null;
        CommonTree char_literal7_tree=null;
        CommonTree char_literal9_tree=null;
        CommonTree char_literal10_tree=null;
        CommonTree char_literal12_tree=null;
        CommonTree char_literal14_tree=null;
        RewriteRuleTokenStream stream_FUNCTION=new RewriteRuleTokenStream(adaptor,"token FUNCTION");
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_30=new RewriteRuleTokenStream(adaptor,"token 30");
        RewriteRuleTokenStream stream_31=new RewriteRuleTokenStream(adaptor,"token 31");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        RewriteRuleSubtreeStream stream_additiveExpression=new RewriteRuleSubtreeStream(adaptor,"rule additiveExpression");
        RewriteRuleSubtreeStream stream_argumentList=new RewriteRuleSubtreeStream(adaptor,"rule argumentList");
        RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
        try {
            // src/SL.g:53:3: ( 'function' name '(' ( argumentList )? ')' ':' type '{' additiveExpression '}' -> name type ^( ARGUMENT_LIST ( argumentList )? ) ^( EXPRESSION additiveExpression ) )
            // src/SL.g:53:5: 'function' name '(' ( argumentList )? ')' ':' type '{' additiveExpression '}'
            {
            string_literal5=(Token)match(input,FUNCTION,FOLLOW_FUNCTION_in_functionDeclaration420);  
            stream_FUNCTION.add(string_literal5);

            pushFollow(FOLLOW_name_in_functionDeclaration422);
            name6=name();

            state._fsp--;

            stream_name.add(name6.getTree());
            char_literal7=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_functionDeclaration424);  
            stream_LPAREN.add(char_literal7);

            // src/SL.g:53:25: ( argumentList )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==IDENTIFIER) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // src/SL.g:53:25: argumentList
                    {
                    pushFollow(FOLLOW_argumentList_in_functionDeclaration426);
                    argumentList8=argumentList();

                    state._fsp--;

                    stream_argumentList.add(argumentList8.getTree());

                    }
                    break;

            }

            char_literal9=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_functionDeclaration429);  
            stream_RPAREN.add(char_literal9);

            char_literal10=(Token)match(input,COLON,FOLLOW_COLON_in_functionDeclaration431);  
            stream_COLON.add(char_literal10);

            pushFollow(FOLLOW_type_in_functionDeclaration433);
            type11=type();

            state._fsp--;

            stream_type.add(type11.getTree());
            char_literal12=(Token)match(input,30,FOLLOW_30_in_functionDeclaration435);  
            stream_30.add(char_literal12);

            pushFollow(FOLLOW_additiveExpression_in_functionDeclaration437);
            additiveExpression13=additiveExpression();

            state._fsp--;

            stream_additiveExpression.add(additiveExpression13.getTree());
            char_literal14=(Token)match(input,31,FOLLOW_31_in_functionDeclaration439);  
            stream_31.add(char_literal14);



            // AST REWRITE
            // elements: name, additiveExpression, argumentList, type
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 53:79: -> name type ^( ARGUMENT_LIST ( argumentList )? ) ^( EXPRESSION additiveExpression )
            {
                adaptor.addChild(root_0, stream_name.nextTree());
                adaptor.addChild(root_0, stream_type.nextTree());
                // src/SL.g:53:93: ^( ARGUMENT_LIST ( argumentList )? )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARGUMENT_LIST, "ARGUMENT_LIST"), root_1);

                // src/SL.g:53:109: ( argumentList )?
                if ( stream_argumentList.hasNext() ) {
                    adaptor.addChild(root_1, stream_argumentList.nextTree());

                }
                stream_argumentList.reset();

                adaptor.addChild(root_0, root_1);
                }
                // src/SL.g:53:124: ^( EXPRESSION additiveExpression )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXPRESSION, "EXPRESSION"), root_1);

                adaptor.addChild(root_1, stream_additiveExpression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "functionDeclaration"

    public static class argumentList_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "argumentList"
    // src/SL.g:56:1: argumentList : argument ( ',' argument )* -> argument ( argument )* ;
    public final SLParser.argumentList_return argumentList() throws RecognitionException {
        SLParser.argumentList_return retval = new SLParser.argumentList_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal16=null;
        SLParser.argument_return argument15 = null;

        SLParser.argument_return argument17 = null;


        CommonTree char_literal16_tree=null;
        RewriteRuleTokenStream stream_32=new RewriteRuleTokenStream(adaptor,"token 32");
        RewriteRuleSubtreeStream stream_argument=new RewriteRuleSubtreeStream(adaptor,"rule argument");
        try {
            // src/SL.g:57:3: ( argument ( ',' argument )* -> argument ( argument )* )
            // src/SL.g:57:5: argument ( ',' argument )*
            {
            pushFollow(FOLLOW_argument_in_argumentList472);
            argument15=argument();

            state._fsp--;

            stream_argument.add(argument15.getTree());
            // src/SL.g:57:14: ( ',' argument )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==32) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // src/SL.g:57:15: ',' argument
            	    {
            	    char_literal16=(Token)match(input,32,FOLLOW_32_in_argumentList475);  
            	    stream_32.add(char_literal16);

            	    pushFollow(FOLLOW_argument_in_argumentList477);
            	    argument17=argument();

            	    state._fsp--;

            	    stream_argument.add(argument17.getTree());

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);



            // AST REWRITE
            // elements: argument, argument
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 57:31: -> argument ( argument )*
            {
                adaptor.addChild(root_0, stream_argument.nextTree());
                // src/SL.g:57:43: ( argument )*
                while ( stream_argument.hasNext() ) {
                    adaptor.addChild(root_0, stream_argument.nextTree());

                }
                stream_argument.reset();

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "argumentList"

    public static class argument_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "argument"
    // src/SL.g:60:1: argument : name ':' type -> ^( ARGUMENT name type ) ;
    public final SLParser.argument_return argument() throws RecognitionException {
        SLParser.argument_return retval = new SLParser.argument_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal19=null;
        SLParser.name_return name18 = null;

        SLParser.type_return type20 = null;


        CommonTree char_literal19_tree=null;
        RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
        try {
            // src/SL.g:61:3: ( name ':' type -> ^( ARGUMENT name type ) )
            // src/SL.g:61:5: name ':' type
            {
            pushFollow(FOLLOW_name_in_argument501);
            name18=name();

            state._fsp--;

            stream_name.add(name18.getTree());
            char_literal19=(Token)match(input,COLON,FOLLOW_COLON_in_argument503);  
            stream_COLON.add(char_literal19);

            pushFollow(FOLLOW_type_in_argument505);
            type20=type();

            state._fsp--;

            stream_type.add(type20.getTree());


            // AST REWRITE
            // elements: type, name
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 61:19: -> ^( ARGUMENT name type )
            {
                // src/SL.g:61:22: ^( ARGUMENT name type )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARGUMENT, "ARGUMENT"), root_1);

                adaptor.addChild(root_1, stream_name.nextTree());
                adaptor.addChild(root_1, stream_type.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "argument"

    public static class additiveExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "additiveExpression"
    // src/SL.g:65:1: additiveExpression : multiplicativeExpression ( ( '+' | '-' ) multiplicativeExpression )* ;
    public final SLParser.additiveExpression_return additiveExpression() throws RecognitionException {
        SLParser.additiveExpression_return retval = new SLParser.additiveExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal22=null;
        Token char_literal23=null;
        SLParser.multiplicativeExpression_return multiplicativeExpression21 = null;

        SLParser.multiplicativeExpression_return multiplicativeExpression24 = null;


        CommonTree char_literal22_tree=null;
        CommonTree char_literal23_tree=null;

        try {
            // src/SL.g:66:3: ( multiplicativeExpression ( ( '+' | '-' ) multiplicativeExpression )* )
            // src/SL.g:66:8: multiplicativeExpression ( ( '+' | '-' ) multiplicativeExpression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_multiplicativeExpression_in_additiveExpression532);
            multiplicativeExpression21=multiplicativeExpression();

            state._fsp--;

            adaptor.addChild(root_0, multiplicativeExpression21.getTree());
            // src/SL.g:66:33: ( ( '+' | '-' ) multiplicativeExpression )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>=PLUS && LA6_0<=MINUS)) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // src/SL.g:66:34: ( '+' | '-' ) multiplicativeExpression
            	    {
            	    // src/SL.g:66:34: ( '+' | '-' )
            	    int alt5=2;
            	    int LA5_0 = input.LA(1);

            	    if ( (LA5_0==PLUS) ) {
            	        alt5=1;
            	    }
            	    else if ( (LA5_0==MINUS) ) {
            	        alt5=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 5, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt5) {
            	        case 1 :
            	            // src/SL.g:66:36: '+'
            	            {
            	            char_literal22=(Token)match(input,PLUS,FOLLOW_PLUS_in_additiveExpression537); 
            	            char_literal22_tree = (CommonTree)adaptor.create(char_literal22);
            	            root_0 = (CommonTree)adaptor.becomeRoot(char_literal22_tree, root_0);


            	            }
            	            break;
            	        case 2 :
            	            // src/SL.g:66:43: '-'
            	            {
            	            char_literal23=(Token)match(input,MINUS,FOLLOW_MINUS_in_additiveExpression542); 
            	            char_literal23_tree = (CommonTree)adaptor.create(char_literal23);
            	            root_0 = (CommonTree)adaptor.becomeRoot(char_literal23_tree, root_0);


            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_multiplicativeExpression_in_additiveExpression547);
            	    multiplicativeExpression24=multiplicativeExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, multiplicativeExpression24.getTree());

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "additiveExpression"

    public static class multiplicativeExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multiplicativeExpression"
    // src/SL.g:70:1: multiplicativeExpression : powerExpression ( ( '*' | '/' ) powerExpression )* ;
    public final SLParser.multiplicativeExpression_return multiplicativeExpression() throws RecognitionException {
        SLParser.multiplicativeExpression_return retval = new SLParser.multiplicativeExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal26=null;
        Token char_literal27=null;
        SLParser.powerExpression_return powerExpression25 = null;

        SLParser.powerExpression_return powerExpression28 = null;


        CommonTree char_literal26_tree=null;
        CommonTree char_literal27_tree=null;

        try {
            // src/SL.g:71:3: ( powerExpression ( ( '*' | '/' ) powerExpression )* )
            // src/SL.g:71:7: powerExpression ( ( '*' | '/' ) powerExpression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_powerExpression_in_multiplicativeExpression567);
            powerExpression25=powerExpression();

            state._fsp--;

            adaptor.addChild(root_0, powerExpression25.getTree());
            // src/SL.g:71:23: ( ( '*' | '/' ) powerExpression )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>=STAR && LA8_0<=DIV)) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // src/SL.g:71:25: ( '*' | '/' ) powerExpression
            	    {
            	    // src/SL.g:71:25: ( '*' | '/' )
            	    int alt7=2;
            	    int LA7_0 = input.LA(1);

            	    if ( (LA7_0==STAR) ) {
            	        alt7=1;
            	    }
            	    else if ( (LA7_0==DIV) ) {
            	        alt7=2;
            	    }
            	    else {
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 7, 0, input);

            	        throw nvae;
            	    }
            	    switch (alt7) {
            	        case 1 :
            	            // src/SL.g:71:26: '*'
            	            {
            	            char_literal26=(Token)match(input,STAR,FOLLOW_STAR_in_multiplicativeExpression572); 
            	            char_literal26_tree = (CommonTree)adaptor.create(char_literal26);
            	            root_0 = (CommonTree)adaptor.becomeRoot(char_literal26_tree, root_0);


            	            }
            	            break;
            	        case 2 :
            	            // src/SL.g:71:33: '/'
            	            {
            	            char_literal27=(Token)match(input,DIV,FOLLOW_DIV_in_multiplicativeExpression577); 
            	            char_literal27_tree = (CommonTree)adaptor.create(char_literal27);
            	            root_0 = (CommonTree)adaptor.becomeRoot(char_literal27_tree, root_0);


            	            }
            	            break;

            	    }

            	    pushFollow(FOLLOW_powerExpression_in_multiplicativeExpression582);
            	    powerExpression28=powerExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, powerExpression28.getTree());

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multiplicativeExpression"

    public static class powerExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "powerExpression"
    // src/SL.g:75:1: powerExpression : unaryExpression ( '^' unaryExpression )* ;
    public final SLParser.powerExpression_return powerExpression() throws RecognitionException {
        SLParser.powerExpression_return retval = new SLParser.powerExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal30=null;
        SLParser.unaryExpression_return unaryExpression29 = null;

        SLParser.unaryExpression_return unaryExpression31 = null;


        CommonTree char_literal30_tree=null;

        try {
            // src/SL.g:76:3: ( unaryExpression ( '^' unaryExpression )* )
            // src/SL.g:76:6: unaryExpression ( '^' unaryExpression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_unaryExpression_in_powerExpression601);
            unaryExpression29=unaryExpression();

            state._fsp--;

            adaptor.addChild(root_0, unaryExpression29.getTree());
            // src/SL.g:76:22: ( '^' unaryExpression )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==POWER) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // src/SL.g:76:24: '^' unaryExpression
            	    {
            	    char_literal30=(Token)match(input,POWER,FOLLOW_POWER_in_powerExpression605); 
            	    char_literal30_tree = (CommonTree)adaptor.create(char_literal30);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal30_tree, root_0);

            	    pushFollow(FOLLOW_unaryExpression_in_powerExpression608);
            	    unaryExpression31=unaryExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, unaryExpression31.getTree());

            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "powerExpression"

    public static class unaryExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unaryExpression"
    // src/SL.g:80:1: unaryExpression : ( '+' | '-' )? element ;
    public final SLParser.unaryExpression_return unaryExpression() throws RecognitionException {
        SLParser.unaryExpression_return retval = new SLParser.unaryExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal32=null;
        Token char_literal33=null;
        SLParser.element_return element34 = null;


        CommonTree char_literal32_tree=null;
        CommonTree char_literal33_tree=null;

        try {
            // src/SL.g:81:3: ( ( '+' | '-' )? element )
            // src/SL.g:81:5: ( '+' | '-' )? element
            {
            root_0 = (CommonTree)adaptor.nil();

            // src/SL.g:81:5: ( '+' | '-' )?
            int alt10=3;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==PLUS) ) {
                alt10=1;
            }
            else if ( (LA10_0==MINUS) ) {
                alt10=2;
            }
            switch (alt10) {
                case 1 :
                    // src/SL.g:81:6: '+'
                    {
                    char_literal32=(Token)match(input,PLUS,FOLLOW_PLUS_in_unaryExpression627); 
                    char_literal32_tree = (CommonTree)adaptor.create(char_literal32);
                    root_0 = (CommonTree)adaptor.becomeRoot(char_literal32_tree, root_0);


                    }
                    break;
                case 2 :
                    // src/SL.g:81:13: '-'
                    {
                    char_literal33=(Token)match(input,MINUS,FOLLOW_MINUS_in_unaryExpression632); 
                    char_literal33_tree = (CommonTree)adaptor.create(char_literal33);
                    root_0 = (CommonTree)adaptor.becomeRoot(char_literal33_tree, root_0);


                    }
                    break;

            }

            pushFollow(FOLLOW_element_in_unaryExpression637);
            element34=element();

            state._fsp--;

            adaptor.addChild(root_0, element34.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unaryExpression"

    public static class element_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "element"
    // src/SL.g:84:1: element : ( name '(' ( expressionList )? ')' -> ^( FUNCTION_DECLARATOR name ( expressionList )? ) | literal | '(' additiveExpression ')' -> ^( BRACKETS additiveExpression ) );
    public final SLParser.element_return element() throws RecognitionException {
        SLParser.element_return retval = new SLParser.element_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal36=null;
        Token char_literal38=null;
        Token char_literal40=null;
        Token char_literal42=null;
        SLParser.name_return name35 = null;

        SLParser.expressionList_return expressionList37 = null;

        SLParser.literal_return literal39 = null;

        SLParser.additiveExpression_return additiveExpression41 = null;


        CommonTree char_literal36_tree=null;
        CommonTree char_literal38_tree=null;
        CommonTree char_literal40_tree=null;
        CommonTree char_literal42_tree=null;
        RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
        RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
        RewriteRuleSubtreeStream stream_expressionList=new RewriteRuleSubtreeStream(adaptor,"rule expressionList");
        RewriteRuleSubtreeStream stream_name=new RewriteRuleSubtreeStream(adaptor,"rule name");
        RewriteRuleSubtreeStream stream_additiveExpression=new RewriteRuleSubtreeStream(adaptor,"rule additiveExpression");
        try {
            // src/SL.g:85:3: ( name '(' ( expressionList )? ')' -> ^( FUNCTION_DECLARATOR name ( expressionList )? ) | literal | '(' additiveExpression ')' -> ^( BRACKETS additiveExpression ) )
            int alt12=3;
            switch ( input.LA(1) ) {
            case IDENTIFIER:
                {
                int LA12_1 = input.LA(2);

                if ( (LA12_1==LPAREN) ) {
                    alt12=1;
                }
                else if ( ((LA12_1>=PLUS && LA12_1<=DIV)||LA12_1==SEMI||LA12_1==POWER||LA12_1==RPAREN||(LA12_1>=31 && LA12_1<=32)) ) {
                    alt12=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 12, 1, input);

                    throw nvae;
                }
                }
                break;
            case NUMBER:
                {
                alt12=2;
                }
                break;
            case LPAREN:
                {
                alt12=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // src/SL.g:85:5: name '(' ( expressionList )? ')'
                    {
                    pushFollow(FOLLOW_name_in_element651);
                    name35=name();

                    state._fsp--;

                    stream_name.add(name35.getTree());
                    char_literal36=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_element653);  
                    stream_LPAREN.add(char_literal36);

                    // src/SL.g:85:14: ( expressionList )?
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( ((LA11_0>=PLUS && LA11_0<=MINUS)||LA11_0==LPAREN||(LA11_0>=NUMBER && LA11_0<=IDENTIFIER)) ) {
                        alt11=1;
                    }
                    switch (alt11) {
                        case 1 :
                            // src/SL.g:85:14: expressionList
                            {
                            pushFollow(FOLLOW_expressionList_in_element655);
                            expressionList37=expressionList();

                            state._fsp--;

                            stream_expressionList.add(expressionList37.getTree());

                            }
                            break;

                    }

                    char_literal38=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_element658);  
                    stream_RPAREN.add(char_literal38);



                    // AST REWRITE
                    // elements: expressionList, name
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 85:34: -> ^( FUNCTION_DECLARATOR name ( expressionList )? )
                    {
                        // src/SL.g:85:37: ^( FUNCTION_DECLARATOR name ( expressionList )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FUNCTION_DECLARATOR, "FUNCTION_DECLARATOR"), root_1);

                        adaptor.addChild(root_1, stream_name.nextTree());
                        // src/SL.g:85:64: ( expressionList )?
                        if ( stream_expressionList.hasNext() ) {
                            adaptor.addChild(root_1, stream_expressionList.nextTree());

                        }
                        stream_expressionList.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;
                case 2 :
                    // src/SL.g:86:5: literal
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_literal_in_element676);
                    literal39=literal();

                    state._fsp--;

                    adaptor.addChild(root_0, literal39.getTree());

                    }
                    break;
                case 3 :
                    // src/SL.g:87:5: '(' additiveExpression ')'
                    {
                    char_literal40=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_element682);  
                    stream_LPAREN.add(char_literal40);

                    pushFollow(FOLLOW_additiveExpression_in_element684);
                    additiveExpression41=additiveExpression();

                    state._fsp--;

                    stream_additiveExpression.add(additiveExpression41.getTree());
                    char_literal42=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_element686);  
                    stream_RPAREN.add(char_literal42);



                    // AST REWRITE
                    // elements: additiveExpression
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 87:32: -> ^( BRACKETS additiveExpression )
                    {
                        // src/SL.g:87:35: ^( BRACKETS additiveExpression )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(BRACKETS, "BRACKETS"), root_1);

                        adaptor.addChild(root_1, stream_additiveExpression.nextTree());

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "element"

    public static class expressionList_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expressionList"
    // src/SL.g:91:1: expressionList : additiveExpression ( ',' additiveExpression )* ;
    public final SLParser.expressionList_return expressionList() throws RecognitionException {
        SLParser.expressionList_return retval = new SLParser.expressionList_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal44=null;
        SLParser.additiveExpression_return additiveExpression43 = null;

        SLParser.additiveExpression_return additiveExpression45 = null;


        CommonTree char_literal44_tree=null;

        try {
            // src/SL.g:92:3: ( additiveExpression ( ',' additiveExpression )* )
            // src/SL.g:92:5: additiveExpression ( ',' additiveExpression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_additiveExpression_in_expressionList712);
            additiveExpression43=additiveExpression();

            state._fsp--;

            adaptor.addChild(root_0, additiveExpression43.getTree());
            // src/SL.g:92:24: ( ',' additiveExpression )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==32) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // src/SL.g:92:25: ',' additiveExpression
            	    {
            	    char_literal44=(Token)match(input,32,FOLLOW_32_in_expressionList715); 
            	    char_literal44_tree = (CommonTree)adaptor.create(char_literal44);
            	    adaptor.addChild(root_0, char_literal44_tree);

            	    pushFollow(FOLLOW_additiveExpression_in_expressionList717);
            	    additiveExpression45=additiveExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, additiveExpression45.getTree());

            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expressionList"

    public static class literal_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "literal"
    // src/SL.g:95:1: literal : ( NUMBER | IDENTIFIER );
    public final SLParser.literal_return literal() throws RecognitionException {
        SLParser.literal_return retval = new SLParser.literal_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set46=null;

        CommonTree set46_tree=null;

        try {
            // src/SL.g:96:3: ( NUMBER | IDENTIFIER )
            // src/SL.g:
            {
            root_0 = (CommonTree)adaptor.nil();

            set46=(Token)input.LT(1);
            if ( (input.LA(1)>=NUMBER && input.LA(1)<=IDENTIFIER) ) {
                input.consume();
                adaptor.addChild(root_0, (CommonTree)adaptor.create(set46));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "literal"

    public static class name_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "name"
    // src/SL.g:100:1: name : IDENTIFIER ;
    public final SLParser.name_return name() throws RecognitionException {
        SLParser.name_return retval = new SLParser.name_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token IDENTIFIER47=null;

        CommonTree IDENTIFIER47_tree=null;

        try {
            // src/SL.g:101:3: ( IDENTIFIER )
            // src/SL.g:101:5: IDENTIFIER
            {
            root_0 = (CommonTree)adaptor.nil();

            IDENTIFIER47=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_name753); 
            IDENTIFIER47_tree = (CommonTree)adaptor.create(IDENTIFIER47);
            adaptor.addChild(root_0, IDENTIFIER47_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "name"

    public static class type_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "type"
    // src/SL.g:104:1: type : IDENTIFIER ;
    public final SLParser.type_return type() throws RecognitionException {
        SLParser.type_return retval = new SLParser.type_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token IDENTIFIER48=null;

        CommonTree IDENTIFIER48_tree=null;

        try {
            // src/SL.g:105:3: ( IDENTIFIER )
            // src/SL.g:105:5: IDENTIFIER
            {
            root_0 = (CommonTree)adaptor.nil();

            IDENTIFIER48=(Token)match(input,IDENTIFIER,FOLLOW_IDENTIFIER_in_type768); 
            IDENTIFIER48_tree = (CommonTree)adaptor.create(IDENTIFIER48);
            adaptor.addChild(root_0, IDENTIFIER48_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "type"

    // Delegated rules


 

    public static final BitSet FOLLOW_stat_in_prog296 = new BitSet(new long[]{0x0000000006009032L});
    public static final BitSet FOLLOW_additiveExpression_in_stat311 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_SEMI_in_stat313 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_functionDeclaration_in_stat327 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FUNCTION_in_functionDeclaration420 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_name_in_functionDeclaration422 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_LPAREN_in_functionDeclaration424 = new BitSet(new long[]{0x0000000004002000L});
    public static final BitSet FOLLOW_argumentList_in_functionDeclaration426 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_RPAREN_in_functionDeclaration429 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_COLON_in_functionDeclaration431 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_type_in_functionDeclaration433 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_30_in_functionDeclaration435 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_additiveExpression_in_functionDeclaration437 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_31_in_functionDeclaration439 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_argument_in_argumentList472 = new BitSet(new long[]{0x0000000100000002L});
    public static final BitSet FOLLOW_32_in_argumentList475 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_argument_in_argumentList477 = new BitSet(new long[]{0x0000000100000002L});
    public static final BitSet FOLLOW_name_in_argument501 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_COLON_in_argument503 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_type_in_argument505 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_multiplicativeExpression_in_additiveExpression532 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_PLUS_in_additiveExpression537 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_MINUS_in_additiveExpression542 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_multiplicativeExpression_in_additiveExpression547 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_powerExpression_in_multiplicativeExpression567 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_STAR_in_multiplicativeExpression572 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_DIV_in_multiplicativeExpression577 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_powerExpression_in_multiplicativeExpression582 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_unaryExpression_in_powerExpression601 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_POWER_in_powerExpression605 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_unaryExpression_in_powerExpression608 = new BitSet(new long[]{0x0000000000000802L});
    public static final BitSet FOLLOW_PLUS_in_unaryExpression627 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_MINUS_in_unaryExpression632 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_element_in_unaryExpression637 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_name_in_element651 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_LPAREN_in_element653 = new BitSet(new long[]{0x0000000006003030L});
    public static final BitSet FOLLOW_expressionList_in_element655 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_RPAREN_in_element658 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_literal_in_element676 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_element682 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_additiveExpression_in_element684 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_RPAREN_in_element686 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_additiveExpression_in_expressionList712 = new BitSet(new long[]{0x0000000100000002L});
    public static final BitSet FOLLOW_32_in_expressionList715 = new BitSet(new long[]{0x0000000006001030L});
    public static final BitSet FOLLOW_additiveExpression_in_expressionList717 = new BitSet(new long[]{0x0000000100000002L});
    public static final BitSet FOLLOW_set_in_literal0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_name753 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IDENTIFIER_in_type768 = new BitSet(new long[]{0x0000000000000002L});

}