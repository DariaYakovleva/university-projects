
import java.util.LinkedList;
import java.util.List;
import org.antlr.runtime.tree.Tree;

/**
 *
 * @author raindrop
 */
public class CodeGenerator {

    StringBuilder builder;
    List<StringBuilder> expressions = new LinkedList<StringBuilder>();
    List<StringBuilder> functions = new LinkedList<StringBuilder>();

    public void handle(Tree tree) {

        switch (tree.getType()) {
            case 0: {
                for (int i = 0; i < tree.getChildCount(); i++) {
                    handle(tree.getChild(i));
                }
                break;
            }
            case SLParser.EXPRESSION: {
                builder = new StringBuilder();
                handleExpression(tree.getChild(0));
                expressions.add(builder);
                break;
            }
            case SLParser.FUNCTION_DECLARATION: {
                builder = new StringBuilder();
                handleFunction(tree);
                functions.add(builder);
                break;
            }
            default: {
                System.out.println("DEFAULT: " + tree.getType());
            }
        }
    }

    public void handleExpression(Tree tree) {
        //System.out.println("Handle expression");

        int N = tree.getChildCount();

        //reduce(tree);
        //System.out.println("[expression] N: " + N + ", node: " + tree);

        if (tree.getType() == SLParser.FUNCTION_DECLARATOR) {
            builder.append(tree.getChild(0)).append(" ( ");
            for (int i = 1; i < tree.getChildCount(); i++) {
                handleExpression(tree.getChild(i));
            }
            builder.append(") ");
        } else if (tree.getType() == SLParser.BRACKETS) {
            builder.append("( ");
            handleExpression(tree.getChild(0));
            builder.append(") ");
        } else if ("^".equals(tree.getText())) {
            builder.append("Math.pow( ");
            handleExpression(tree.getChild(0));
            builder.append(", ");
            handleExpression(tree.getChild(1));
            builder.append(") ");


        } else if (N == 0) {
            builder.append(tree).append(" ");
        } else if (N == 1) {
            builder.append(tree);
            handleExpression(tree.getChild(0));
        } else if (N == 2) {
            handleExpression(tree.getChild(0));
            builder.append(tree).append(" ");
            handleExpression(tree.getChild(1));
        }
    }

    public void handleFunction(Tree tree) {
        //System.out.println("Handle function: " + tree.getText());

        String name = tree.getChild(0).getText();
        String type = tree.getChild(1).getText();

        builder.append(type).append(" ");
        builder.append(name).append("( ");

        handleArgumentList(tree.getChild(2));
        builder.append(") { return ");
        handleExpression(tree.getChild(3).getChild(0));

        builder.append("; } ");
    }

    public void handleArgumentList(Tree tree) {

        if (0 < tree.getChildCount()) {
            handleArgument(tree.getChild(0));
            for (int i = 1; i < tree.getChildCount(); i++) {
                builder.append(", ");
                handleArgument(tree.getChild(i));
            }
        }
    }

    public void handleArgument(Tree tree) {
        //System.out.println("Handle argument: " + tree.getText() + " childs: " + tree.getChildCount());
        String name = tree.getChild(0).getText();
        String type = tree.getChild(1).getText();
        builder.append(type).append(" ");
        builder.append(name).append(" ");

    }

    public StringBuilder getSource() {
        StringBuilder res = new StringBuilder();
        res.append("package simple;\n");
        res.append("import static java.lang.Math.*;\n\n");
        res.append("public class Main{\n\n");

        for (StringBuilder function : functions) {
            res.append("  static ").append(function).append("\n\n");
        }

        res.append("  public static void main(String args[]){\n");
        for (StringBuilder expr : expressions) {
            //System.out.println("[code] expr: '" + expr + "'");
            res.append("    System.out.println( \"");
            res.append(expr);
            res.append(" = \" + ( ");
            res.append(expr);
            res.append(") );\n");
        }
        res.append("  }\n");
        res.append("}");
        return res;
    }
}
