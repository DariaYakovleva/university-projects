// $ANTLR 3.2 Sep 23, 2009 12:02:23 D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g 2010-11-19 18:37:31

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class SLLexer extends Lexer {
    public static final int RPAREN=12;
    public static final int STAR=6;
    public static final int NUMBER=14;
    public static final int POWER=10;
    public static final int PLUS=4;
    public static final int DIGIT=15;
    public static final int DIV=7;
    public static final int MINUS=5;
    public static final int DOT=8;
    public static final int EOF=-1;
    public static final int SEMI=9;
    public static final int EXPRESSION=13;
    public static final int LPAREN=11;
    public static final int SKIP=16;

    // delegates
    // delegators

    public SLLexer() {;} 
    public SLLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public SLLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g"; }

    // $ANTLR start "PLUS"
    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:3:6: ( '+' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:3:8: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PLUS"

    // $ANTLR start "MINUS"
    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:4:7: ( '-' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:4:9: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MINUS"

    // $ANTLR start "STAR"
    public final void mSTAR() throws RecognitionException {
        try {
            int _type = STAR;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:5:6: ( '*' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:5:8: '*'
            {
            match('*'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STAR"

    // $ANTLR start "DIV"
    public final void mDIV() throws RecognitionException {
        try {
            int _type = DIV;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:6:5: ( '/' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:6:7: '/'
            {
            match('/'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DIV"

    // $ANTLR start "DOT"
    public final void mDOT() throws RecognitionException {
        try {
            int _type = DOT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:7:5: ( '.' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:7:7: '.'
            {
            match('.'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "DOT"

    // $ANTLR start "SEMI"
    public final void mSEMI() throws RecognitionException {
        try {
            int _type = SEMI;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:8:6: ( ';' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:8:8: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SEMI"

    // $ANTLR start "POWER"
    public final void mPOWER() throws RecognitionException {
        try {
            int _type = POWER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:9:7: ( '^' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:9:9: '^'
            {
            match('^'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "POWER"

    // $ANTLR start "LPAREN"
    public final void mLPAREN() throws RecognitionException {
        try {
            int _type = LPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:10:8: ( '(' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:10:10: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LPAREN"

    // $ANTLR start "RPAREN"
    public final void mRPAREN() throws RecognitionException {
        try {
            int _type = RPAREN;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:11:8: ( ')' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:11:10: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "RPAREN"

    // $ANTLR start "NUMBER"
    public final void mNUMBER() throws RecognitionException {
        try {
            int _type = NUMBER;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:3: ( ( DIGIT )+ ( '.' ( DIGIT )+ )* )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:5: ( DIGIT )+ ( '.' ( DIGIT )+ )*
            {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:5: ( DIGIT )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:5: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);

            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:12: ( '.' ( DIGIT )+ )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0=='.') ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:13: '.' ( DIGIT )+
            	    {
            	    match('.'); 
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:17: ( DIGIT )+
            	    int cnt2=0;
            	    loop2:
            	    do {
            	        int alt2=2;
            	        int LA2_0 = input.LA(1);

            	        if ( ((LA2_0>='0' && LA2_0<='9')) ) {
            	            alt2=1;
            	        }


            	        switch (alt2) {
            	    	case 1 :
            	    	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:56:17: DIGIT
            	    	    {
            	    	    mDIGIT(); 

            	    	    }
            	    	    break;

            	    	default :
            	    	    if ( cnt2 >= 1 ) break loop2;
            	                EarlyExitException eee =
            	                    new EarlyExitException(2, input);
            	                throw eee;
            	        }
            	        cnt2++;
            	    } while (true);


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "NUMBER"

    // $ANTLR start "DIGIT"
    public final void mDIGIT() throws RecognitionException {
        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:60:3: ( '0' .. '9' )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:60:5: '0' .. '9'
            {
            matchRange('0','9'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end "DIGIT"

    // $ANTLR start "SKIP"
    public final void mSKIP() throws RecognitionException {
        try {
            int _type = SKIP;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:66:3: ( ( ' ' | '\\r' | '\\t' | '\\n' | ';' ) )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:66:5: ( ' ' | '\\r' | '\\t' | '\\n' | ';' )
            {
            if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' '||input.LA(1)==';' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}

             skip(); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "SKIP"

    public void mTokens() throws RecognitionException {
        // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:8: ( PLUS | MINUS | STAR | DIV | DOT | SEMI | POWER | LPAREN | RPAREN | NUMBER | SKIP )
        int alt4=11;
        alt4 = dfa4.predict(input);
        switch (alt4) {
            case 1 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:10: PLUS
                {
                mPLUS(); 

                }
                break;
            case 2 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:15: MINUS
                {
                mMINUS(); 

                }
                break;
            case 3 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:21: STAR
                {
                mSTAR(); 

                }
                break;
            case 4 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:26: DIV
                {
                mDIV(); 

                }
                break;
            case 5 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:30: DOT
                {
                mDOT(); 

                }
                break;
            case 6 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:34: SEMI
                {
                mSEMI(); 

                }
                break;
            case 7 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:39: POWER
                {
                mPOWER(); 

                }
                break;
            case 8 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:45: LPAREN
                {
                mLPAREN(); 

                }
                break;
            case 9 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:52: RPAREN
                {
                mRPAREN(); 

                }
                break;
            case 10 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:59: NUMBER
                {
                mNUMBER(); 

                }
                break;
            case 11 :
                // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:1:66: SKIP
                {
                mSKIP(); 

                }
                break;

        }

    }


    protected DFA4 dfa4 = new DFA4(this);
    static final String DFA4_eotS =
        "\15\uffff";
    static final String DFA4_eofS =
        "\15\uffff";
    static final String DFA4_minS =
        "\1\11\14\uffff";
    static final String DFA4_maxS =
        "\1\136\14\uffff";
    static final String DFA4_acceptS =
        "\1\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\6";
    static final String DFA4_specialS =
        "\15\uffff}>";
    static final String[] DFA4_transitionS = {
            "\2\13\2\uffff\1\13\22\uffff\1\13\7\uffff\1\10\1\11\1\3\1\1"+
            "\1\uffff\1\2\1\5\1\4\12\12\1\uffff\1\6\42\uffff\1\7",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA4_eot = DFA.unpackEncodedString(DFA4_eotS);
    static final short[] DFA4_eof = DFA.unpackEncodedString(DFA4_eofS);
    static final char[] DFA4_min = DFA.unpackEncodedStringToUnsignedChars(DFA4_minS);
    static final char[] DFA4_max = DFA.unpackEncodedStringToUnsignedChars(DFA4_maxS);
    static final short[] DFA4_accept = DFA.unpackEncodedString(DFA4_acceptS);
    static final short[] DFA4_special = DFA.unpackEncodedString(DFA4_specialS);
    static final short[][] DFA4_transition;

    static {
        int numStates = DFA4_transitionS.length;
        DFA4_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA4_transition[i] = DFA.unpackEncodedString(DFA4_transitionS[i]);
        }
    }

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = DFA4_eot;
            this.eof = DFA4_eof;
            this.min = DFA4_min;
            this.max = DFA4_max;
            this.accept = DFA4_accept;
            this.special = DFA4_special;
            this.transition = DFA4_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( PLUS | MINUS | STAR | DIV | DOT | SEMI | POWER | LPAREN | RPAREN | NUMBER | SKIP );";
        }
    }
 

}