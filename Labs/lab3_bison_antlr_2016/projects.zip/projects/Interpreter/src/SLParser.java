// $ANTLR 3.2 Sep 23, 2009 12:02:23 D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g 2010-11-19 18:37:30

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class SLParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "PLUS", "MINUS", "STAR", "DIV", "DOT", "SEMI", "POWER", "LPAREN", "RPAREN", "EXPRESSION", "NUMBER", "DIGIT", "SKIP"
    };
    public static final int RPAREN=12;
    public static final int STAR=6;
    public static final int NUMBER=14;
    public static final int POWER=10;
    public static final int PLUS=4;
    public static final int DIGIT=15;
    public static final int MINUS=5;
    public static final int DIV=7;
    public static final int DOT=8;
    public static final int EOF=-1;
    public static final int SEMI=9;
    public static final int EXPRESSION=13;
    public static final int LPAREN=11;
    public static final int SKIP=16;

    // delegates
    // delegators


        public SLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SLParser.tokenNames; }
    public String getGrammarFileName() { return "D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g"; }


    public static class prog_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prog"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:26:1: prog : add ;
    public final SLParser.prog_return prog() throws RecognitionException {
        SLParser.prog_return retval = new SLParser.prog_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        SLParser.add_return add1 = null;



        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:27:3: ( add )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:27:5: add
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_add_in_prog188);
            add1=add();

            state._fsp--;

            adaptor.addChild(root_0, add1.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prog"

    public static class add_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "add"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:30:1: add : mult ( ( '+' | '-' ) mult )* ;
    public final SLParser.add_return add() throws RecognitionException {
        SLParser.add_return retval = new SLParser.add_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set3=null;
        SLParser.mult_return mult2 = null;

        SLParser.mult_return mult4 = null;


        CommonTree set3_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:31:3: ( mult ( ( '+' | '-' ) mult )* )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:31:8: mult ( ( '+' | '-' ) mult )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_mult_in_add204);
            mult2=mult();

            state._fsp--;

            adaptor.addChild(root_0, mult2.getTree());
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:31:13: ( ( '+' | '-' ) mult )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=PLUS && LA1_0<=MINUS)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:31:14: ( '+' | '-' ) mult
            	    {
            	    set3=(Token)input.LT(1);
            	    if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, (CommonTree)adaptor.create(set3));
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_mult_in_add217);
            	    mult4=mult();

            	    state._fsp--;

            	    adaptor.addChild(root_0, mult4.getTree());

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "add"

    public static class mult_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "mult"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:34:1: mult : power ( ( '*' | '/' ) power )* ;
    public final SLParser.mult_return mult() throws RecognitionException {
        SLParser.mult_return retval = new SLParser.mult_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set6=null;
        SLParser.power_return power5 = null;

        SLParser.power_return power7 = null;


        CommonTree set6_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:35:3: ( power ( ( '*' | '/' ) power )* )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:35:7: power ( ( '*' | '/' ) power )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_power_in_mult236);
            power5=power();

            state._fsp--;

            adaptor.addChild(root_0, power5.getTree());
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:35:13: ( ( '*' | '/' ) power )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=STAR && LA2_0<=DIV)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:35:15: ( '*' | '/' ) power
            	    {
            	    set6=(Token)input.LT(1);
            	    if ( (input.LA(1)>=STAR && input.LA(1)<=DIV) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, (CommonTree)adaptor.create(set6));
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_power_in_mult249);
            	    power7=power();

            	    state._fsp--;

            	    adaptor.addChild(root_0, power7.getTree());

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "mult"

    public static class power_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "power"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:39:1: power : unary ( '^' unary )* ;
    public final SLParser.power_return power() throws RecognitionException {
        SLParser.power_return retval = new SLParser.power_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal9=null;
        SLParser.unary_return unary8 = null;

        SLParser.unary_return unary10 = null;


        CommonTree char_literal9_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:40:3: ( unary ( '^' unary )* )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:40:6: unary ( '^' unary )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_unary_in_power268);
            unary8=unary();

            state._fsp--;

            adaptor.addChild(root_0, unary8.getTree());
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:40:12: ( '^' unary )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==POWER) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:40:14: '^' unary
            	    {
            	    char_literal9=(Token)match(input,POWER,FOLLOW_POWER_in_power272); 
            	    char_literal9_tree = (CommonTree)adaptor.create(char_literal9);
            	    adaptor.addChild(root_0, char_literal9_tree);

            	    pushFollow(FOLLOW_unary_in_power274);
            	    unary10=unary();

            	    state._fsp--;

            	    adaptor.addChild(root_0, unary10.getTree());

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "power"

    public static class unary_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unary"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:44:1: unary : ( '+' | '-' )? element ;
    public final SLParser.unary_return unary() throws RecognitionException {
        SLParser.unary_return retval = new SLParser.unary_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set11=null;
        SLParser.element_return element12 = null;


        CommonTree set11_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:45:3: ( ( '+' | '-' )? element )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:45:5: ( '+' | '-' )? element
            {
            root_0 = (CommonTree)adaptor.nil();

            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:45:5: ( '+' | '-' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=PLUS && LA4_0<=MINUS)) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:
                    {
                    set11=(Token)input.LT(1);
                    if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
                        input.consume();
                        adaptor.addChild(root_0, (CommonTree)adaptor.create(set11));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            pushFollow(FOLLOW_element_in_unary300);
            element12=element();

            state._fsp--;

            adaptor.addChild(root_0, element12.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unary"

    public static class element_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "element"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:48:1: element : ( NUMBER | '(' add ')' );
    public final SLParser.element_return element() throws RecognitionException {
        SLParser.element_return retval = new SLParser.element_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NUMBER13=null;
        Token char_literal14=null;
        Token char_literal16=null;
        SLParser.add_return add15 = null;


        CommonTree NUMBER13_tree=null;
        CommonTree char_literal14_tree=null;
        CommonTree char_literal16_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:49:3: ( NUMBER | '(' add ')' )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==NUMBER) ) {
                alt5=1;
            }
            else if ( (LA5_0==LPAREN) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:49:5: NUMBER
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    NUMBER13=(Token)match(input,NUMBER,FOLLOW_NUMBER_in_element314); 
                    NUMBER13_tree = (CommonTree)adaptor.create(NUMBER13);
                    adaptor.addChild(root_0, NUMBER13_tree);


                    }
                    break;
                case 2 :
                    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Interpreter\\src\\SL.g:50:5: '(' add ')'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    char_literal14=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_element320); 
                    char_literal14_tree = (CommonTree)adaptor.create(char_literal14);
                    adaptor.addChild(root_0, char_literal14_tree);

                    pushFollow(FOLLOW_add_in_element322);
                    add15=add();

                    state._fsp--;

                    adaptor.addChild(root_0, add15.getTree());
                    char_literal16=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_element324); 
                    char_literal16_tree = (CommonTree)adaptor.create(char_literal16);
                    adaptor.addChild(root_0, char_literal16_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "element"

    // Delegated rules


 

    public static final BitSet FOLLOW_add_in_prog188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_mult_in_add204 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_set_in_add207 = new BitSet(new long[]{0x0000000000004830L});
    public static final BitSet FOLLOW_mult_in_add217 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_power_in_mult236 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_set_in_mult240 = new BitSet(new long[]{0x0000000000004830L});
    public static final BitSet FOLLOW_power_in_mult249 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_unary_in_power268 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_POWER_in_power272 = new BitSet(new long[]{0x0000000000004830L});
    public static final BitSet FOLLOW_unary_in_power274 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_set_in_unary291 = new BitSet(new long[]{0x0000000000004830L});
    public static final BitSet FOLLOW_element_in_unary300 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_element314 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_element320 = new BitSet(new long[]{0x0000000000004830L});
    public static final BitSet FOLLOW_add_in_element322 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_RPAREN_in_element324 = new BitSet(new long[]{0x0000000000000002L});

}