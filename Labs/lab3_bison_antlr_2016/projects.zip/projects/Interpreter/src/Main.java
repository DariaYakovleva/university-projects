
import java.io.File;
import java.io.FileInputStream;
import org.antlr.runtime.ANTLRInputStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.Tree;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author andromeda
 */
public class Main {

    public static void main(String[] args) throws Exception {

        File program = new File("program.txt");
        ANTLRInputStream input = new ANTLRInputStream(new FileInputStream(program));
        SLLexer lexer = new SLLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        SLParser parser = new SLParser(tokens);
        CommonTree tree = (CommonTree) parser.prog().getTree();

        System.out.println("Tree: " + tree + "\n");
        visit(tree, "");
        System.out.println("");

    }

    static void visit(Tree tree, String s){
        //System.out.println(s + "text: " + tree.getText() + ", type: " + tree.getType() + ", childs: " + tree.getChildCount());
        System.out.println(s + "text: " + tree.getText() + ", childs: " + tree.getChildCount());
        for(int i=0; i< tree.getChildCount(); i++){
            visit(tree.getChild(i), s +"  ");
        }
    }



}
