// $ANTLR 3.2 Sep 23, 2009 12:02:23 D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g 2010-11-19 18:24:34

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class SLParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "PLUS", "MINUS", "STAR", "DIV", "DOT", "SEMI", "POWER", "LPAREN", "RPAREN", "NUMBER", "DIGIT", "SKIP"
    };
    public static final int RPAREN=12;
    public static final int STAR=6;
    public static final int NUMBER=13;
    public static final int POWER=10;
    public static final int PLUS=4;
    public static final int DIGIT=14;
    public static final int MINUS=5;
    public static final int DIV=7;
    public static final int DOT=8;
    public static final int EOF=-1;
    public static final int SEMI=9;
    public static final int LPAREN=11;
    public static final int SKIP=15;

    // delegates
    // delegators


        public SLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public SLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return SLParser.tokenNames; }
    public String getGrammarFileName() { return "D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g"; }


    public static class prog_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "prog"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:24:1: prog : additiveExpression ;
    public final SLParser.prog_return prog() throws RecognitionException {
        SLParser.prog_return retval = new SLParser.prog_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        SLParser.additiveExpression_return additiveExpression1 = null;



        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:25:3: ( additiveExpression )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:25:5: additiveExpression
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_additiveExpression_in_prog180);
            additiveExpression1=additiveExpression();

            state._fsp--;

            adaptor.addChild(root_0, additiveExpression1.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "prog"

    public static class additiveExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "additiveExpression"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:28:1: additiveExpression : multiplicativeExpression ( ( '+' | '-' ) multiplicativeExpression )* ;
    public final SLParser.additiveExpression_return additiveExpression() throws RecognitionException {
        SLParser.additiveExpression_return retval = new SLParser.additiveExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set3=null;
        SLParser.multiplicativeExpression_return multiplicativeExpression2 = null;

        SLParser.multiplicativeExpression_return multiplicativeExpression4 = null;


        CommonTree set3_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:29:3: ( multiplicativeExpression ( ( '+' | '-' ) multiplicativeExpression )* )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:29:8: multiplicativeExpression ( ( '+' | '-' ) multiplicativeExpression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_multiplicativeExpression_in_additiveExpression196);
            multiplicativeExpression2=multiplicativeExpression();

            state._fsp--;

            adaptor.addChild(root_0, multiplicativeExpression2.getTree());
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:29:33: ( ( '+' | '-' ) multiplicativeExpression )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=PLUS && LA1_0<=MINUS)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:29:34: ( '+' | '-' ) multiplicativeExpression
            	    {
            	    set3=(Token)input.LT(1);
            	    if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, (CommonTree)adaptor.create(set3));
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_multiplicativeExpression_in_additiveExpression209);
            	    multiplicativeExpression4=multiplicativeExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, multiplicativeExpression4.getTree());

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "additiveExpression"

    public static class multiplicativeExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multiplicativeExpression"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:32:1: multiplicativeExpression : powerExpression ( ( '*' | '/' ) powerExpression )* ;
    public final SLParser.multiplicativeExpression_return multiplicativeExpression() throws RecognitionException {
        SLParser.multiplicativeExpression_return retval = new SLParser.multiplicativeExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set6=null;
        SLParser.powerExpression_return powerExpression5 = null;

        SLParser.powerExpression_return powerExpression7 = null;


        CommonTree set6_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:33:3: ( powerExpression ( ( '*' | '/' ) powerExpression )* )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:33:7: powerExpression ( ( '*' | '/' ) powerExpression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_powerExpression_in_multiplicativeExpression228);
            powerExpression5=powerExpression();

            state._fsp--;

            adaptor.addChild(root_0, powerExpression5.getTree());
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:33:23: ( ( '*' | '/' ) powerExpression )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=STAR && LA2_0<=DIV)) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:33:25: ( '*' | '/' ) powerExpression
            	    {
            	    set6=(Token)input.LT(1);
            	    if ( (input.LA(1)>=STAR && input.LA(1)<=DIV) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, (CommonTree)adaptor.create(set6));
            	        state.errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        throw mse;
            	    }

            	    pushFollow(FOLLOW_powerExpression_in_multiplicativeExpression241);
            	    powerExpression7=powerExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, powerExpression7.getTree());

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multiplicativeExpression"

    public static class powerExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "powerExpression"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:37:1: powerExpression : unaryExpression ( '^' unaryExpression )* ;
    public final SLParser.powerExpression_return powerExpression() throws RecognitionException {
        SLParser.powerExpression_return retval = new SLParser.powerExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal9=null;
        SLParser.unaryExpression_return unaryExpression8 = null;

        SLParser.unaryExpression_return unaryExpression10 = null;


        CommonTree char_literal9_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:38:3: ( unaryExpression ( '^' unaryExpression )* )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:38:6: unaryExpression ( '^' unaryExpression )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_unaryExpression_in_powerExpression260);
            unaryExpression8=unaryExpression();

            state._fsp--;

            adaptor.addChild(root_0, unaryExpression8.getTree());
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:38:22: ( '^' unaryExpression )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==POWER) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:38:24: '^' unaryExpression
            	    {
            	    char_literal9=(Token)match(input,POWER,FOLLOW_POWER_in_powerExpression264); 
            	    char_literal9_tree = (CommonTree)adaptor.create(char_literal9);
            	    adaptor.addChild(root_0, char_literal9_tree);

            	    pushFollow(FOLLOW_unaryExpression_in_powerExpression266);
            	    unaryExpression10=unaryExpression();

            	    state._fsp--;

            	    adaptor.addChild(root_0, unaryExpression10.getTree());

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "powerExpression"

    public static class unaryExpression_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "unaryExpression"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:42:1: unaryExpression : ( '+' | '-' )? element ;
    public final SLParser.unaryExpression_return unaryExpression() throws RecognitionException {
        SLParser.unaryExpression_return retval = new SLParser.unaryExpression_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set11=null;
        SLParser.element_return element12 = null;


        CommonTree set11_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:43:3: ( ( '+' | '-' )? element )
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:43:5: ( '+' | '-' )? element
            {
            root_0 = (CommonTree)adaptor.nil();

            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:43:5: ( '+' | '-' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=PLUS && LA4_0<=MINUS)) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:
                    {
                    set11=(Token)input.LT(1);
                    if ( (input.LA(1)>=PLUS && input.LA(1)<=MINUS) ) {
                        input.consume();
                        adaptor.addChild(root_0, (CommonTree)adaptor.create(set11));
                        state.errorRecovery=false;
                    }
                    else {
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }


                    }
                    break;

            }

            pushFollow(FOLLOW_element_in_unaryExpression293);
            element12=element();

            state._fsp--;

            adaptor.addChild(root_0, element12.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "unaryExpression"

    public static class element_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "element"
    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:46:1: element : ( NUMBER | '(' additiveExpression ')' );
    public final SLParser.element_return element() throws RecognitionException {
        SLParser.element_return retval = new SLParser.element_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NUMBER13=null;
        Token char_literal14=null;
        Token char_literal16=null;
        SLParser.additiveExpression_return additiveExpression15 = null;


        CommonTree NUMBER13_tree=null;
        CommonTree char_literal14_tree=null;
        CommonTree char_literal16_tree=null;

        try {
            // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:47:3: ( NUMBER | '(' additiveExpression ')' )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==NUMBER) ) {
                alt5=1;
            }
            else if ( (LA5_0==LPAREN) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:47:5: NUMBER
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    NUMBER13=(Token)match(input,NUMBER,FOLLOW_NUMBER_in_element307); 
                    NUMBER13_tree = (CommonTree)adaptor.create(NUMBER13);
                    adaptor.addChild(root_0, NUMBER13_tree);


                    }
                    break;
                case 2 :
                    // D:\\Sun\\Constructor\\compiler\\samples\\util\\netbeans\\projects\\Expression\\src\\SL.g:48:5: '(' additiveExpression ')'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    char_literal14=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_element313); 
                    char_literal14_tree = (CommonTree)adaptor.create(char_literal14);
                    adaptor.addChild(root_0, char_literal14_tree);

                    pushFollow(FOLLOW_additiveExpression_in_element315);
                    additiveExpression15=additiveExpression();

                    state._fsp--;

                    adaptor.addChild(root_0, additiveExpression15.getTree());
                    char_literal16=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_element317); 
                    char_literal16_tree = (CommonTree)adaptor.create(char_literal16);
                    adaptor.addChild(root_0, char_literal16_tree);


                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "element"

    // Delegated rules


 

    public static final BitSet FOLLOW_additiveExpression_in_prog180 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_multiplicativeExpression_in_additiveExpression196 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_set_in_additiveExpression199 = new BitSet(new long[]{0x0000000000002830L});
    public static final BitSet FOLLOW_multiplicativeExpression_in_additiveExpression209 = new BitSet(new long[]{0x0000000000000032L});
    public static final BitSet FOLLOW_powerExpression_in_multiplicativeExpression228 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_set_in_multiplicativeExpression232 = new BitSet(new long[]{0x0000000000002830L});
    public static final BitSet FOLLOW_powerExpression_in_multiplicativeExpression241 = new BitSet(new long[]{0x00000000000000C2L});
    public static final BitSet FOLLOW_unaryExpression_in_powerExpression260 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_POWER_in_powerExpression264 = new BitSet(new long[]{0x0000000000002830L});
    public static final BitSet FOLLOW_unaryExpression_in_powerExpression266 = new BitSet(new long[]{0x0000000000000402L});
    public static final BitSet FOLLOW_set_in_unaryExpression284 = new BitSet(new long[]{0x0000000000002830L});
    public static final BitSet FOLLOW_element_in_unaryExpression293 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NUMBER_in_element307 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LPAREN_in_element313 = new BitSet(new long[]{0x0000000000002830L});
    public static final BitSet FOLLOW_additiveExpression_in_element315 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_RPAREN_in_element317 = new BitSet(new long[]{0x0000000000000002L});

}