
import java.io.File;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author andromeda
 */
public class Grammar {

    public static void main(String[] args) {

        String src = new File(".").getAbsolutePath();
        String grammar = new File("SL.g").getAbsolutePath();

        org.antlr.Tool.main(new String[]{"-o", src, grammar});
    }
}
