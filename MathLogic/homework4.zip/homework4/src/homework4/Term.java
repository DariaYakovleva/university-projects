package homework4;

public interface Term extends Expression{      
    
}