
This is the J804 distribution.

For more information see: http://www.jsoftware.com/jwiki/System/Installation.

Command scripts:

jconsole.cmd        - load Jconsole
jreg.cmd            - register J automation server
bin\jhs.bat         - load JHS server

If the Qt IDE is already installed:
jqt.cmd             - load JQt
updatejqt.cmd       - update JQt binaries

You may create desktop shortcuts that call these scripts. Suitable icons are in the bin/icons directory.
For a jqt.cmd shortcut, select run Minimized. This hides any initial display of the windows console.
