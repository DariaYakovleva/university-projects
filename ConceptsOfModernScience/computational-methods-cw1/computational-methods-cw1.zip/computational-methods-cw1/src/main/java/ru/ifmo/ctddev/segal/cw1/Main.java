package ru.ifmo.ctddev.segal.cw1;

/**
 * @author Daniyar Itegulov
 */
public class Main {

    public static void main(String[] args) {
        // TODO: implement
    }
}
