
public class PowerException extends Exception3 {
	public PowerException(String message) {
		super(message);
	}
}