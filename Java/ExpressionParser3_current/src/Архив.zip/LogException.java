
public class LogException extends Exception3{
	public LogException(String message) {
		super(message);
	}
}