
public class OverException extends Exception3{
	public OverException(String message) {
		super(message);
	}
}