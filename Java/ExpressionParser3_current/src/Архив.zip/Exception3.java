public abstract class Exception3 extends Exception{

	public Exception3(String message) {
		super(message);
	}
	
}
