public interface Function<T extends MyNumber<T>> {
	 T function(T a);
}
