public interface Expression3 <T extends MyNumber<T>>{      
    public T evaluate(T x, T y, T z) throws Exception3;   
}
