
public class ZeroException extends Exception3 {
	public ZeroException(String message) {
		super(message);
	}
}
